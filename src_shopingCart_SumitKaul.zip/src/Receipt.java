
public interface Receipt {
	
	public void display();

}
