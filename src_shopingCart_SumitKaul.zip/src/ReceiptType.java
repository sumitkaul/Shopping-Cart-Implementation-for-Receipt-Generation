//enum for extending the Receipt for various methods like web or pdf or other types of receipts 
public enum ReceiptType {
	
	Print,
	Web,
	Pdf,
	
	

}
